define(["require", "exports", "preact/jsx-runtime", "ojs/ojbutton", "ojs/ojlabel"], function (require, exports, jsx_runtime_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    const SignupSection = ({ title, description, icon, image, setUserTypeFunc, }) => {
        const customSignUp = (e) => {
            var _a;
            setUserTypeFunc(title);
            (_a = document.querySelector("#slide-out-container")) === null || _a === void 0 ? void 0 : _a.classList.toggle("show");
        };
        const imageDivElement = () => {
            return ((0, jsx_runtime_1.jsx)("div", Object.assign({ class: "signup__container__image" }, { children: (0, jsx_runtime_1.jsx)("img", { src: image, alt: "BeneficiaryImage" }) })));
        };
        return ((0, jsx_runtime_1.jsx)("div", { children: (0, jsx_runtime_1.jsxs)("div", Object.assign({ class: "signup__container" }, { children: [title == "Donor" && imageDivElement(), (0, jsx_runtime_1.jsxs)("div", Object.assign({ class: "signup__container__calltoaction" }, { children: [(0, jsx_runtime_1.jsxs)("h2", { children: [title + " ", (0, jsx_runtime_1.jsx)("span", { class: icon })] }), (0, jsx_runtime_1.jsx)("p", { children: description }), (0, jsx_runtime_1.jsx)("oj-button", Object.assign({ onojAction: customSignUp }, { children: "Sign Up!" }))] })), title !== "Donor" && imageDivElement()] })) }));
    };
    exports.default = SignupSection;
});
//# sourceMappingURL=signup-section.js.map