export = {
 "root": {
  "donor-page": {
    "sampleString": "The strings file can be used to manage translatable resources"
  }
 },
};