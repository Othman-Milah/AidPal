var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
define(["require", "exports", "preact/jsx-runtime", "ojs/ojvcomponent", "preact/hooks", "ojs/ojcontext", "./footer", "./header", "./content/index", "ojs/ojcorerouter", "ojs/ojurlparamadapter"], function (require, exports, jsx_runtime_1, ojvcomponent_1, hooks_1, Context, footer_1, header_1, index_1, CoreRouter, UrlParamAdapter) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.App = void 0;
    const routeArray = [
        { path: "", redirect: "landing-page" },
        { path: "landing-page", detail: { label: "LandingPage" } },
        { path: "sign-in", detail: { label: "SignIn" } },
        { path: "donor-page", detail: { label: "DonorPage" } },
    ];
    const router = new CoreRouter(routeArray, {
        urlAdapter: new UrlParamAdapter(),
    });
    const pageEventHandler = (value) => {
        router.go({ path: value });
    };
    exports.App = (0, ojvcomponent_1.registerCustomElement)("app-root", ({ appName = "AidPal", userLogin = "" }) => {
        const [routePath, setRoutePath] = (0, hooks_1.useState)("");
        const [loggedInUser, setLoggedInUser] = (0, hooks_1.useState)("");
        const [user, setUser] = (0, hooks_1.useState)({});
        (0, hooks_1.useEffect)(() => {
            Context.getPageContext().getBusyContext().applicationBootstrapComplete();
            router.currentState.subscribe(routerUpdated);
            router.sync();
        }, [routePath]);
        const fetchUserIfExists = (username, password) => __awaiter(void 0, void 0, void 0, function* () {
            alert("checking for username " + username);
            let found = false;
            try {
                const response = yield fetch("http://localhost:8080/donors/list");
                const data = yield response.json();
                data.forEach((userInfo) => {
                    if (userInfo.username === username &&
                        userInfo.username === username) {
                        alert("user found");
                        found = true;
                        setUser(userInfo);
                    }
                });
            }
            catch (error) {
                console.error(error);
            }
            return found;
        });
        const routerUpdated = (actionable) => {
            var _a;
            const newPath = (_a = actionable.state) === null || _a === void 0 ? void 0 : _a.path;
            setRoutePath(newPath);
        };
        const updateLoggedInUser = (name) => {
            setLoggedInUser(name);
        };
        return ((0, jsx_runtime_1.jsxs)("div", Object.assign({ id: "appContainer", class: "oj-web-applayout-page" }, { children: [(0, jsx_runtime_1.jsx)(header_1.Header, { appName: appName, userLogin: loggedInUser, pageEventHandler: pageEventHandler, updateLoggedInUser: updateLoggedInUser }), (0, jsx_runtime_1.jsx)(index_1.Content, { page: routePath, pageEventHandler: pageEventHandler, updateLoggedInUser: updateLoggedInUser, fetchUserIfExists: fetchUserIfExists }), (0, jsx_runtime_1.jsx)(footer_1.Footer, {})] })));
    }, "App", { "properties": { "appName": { "type": "string" }, "userLogin": { "type": "string" } } }, { "appName": "AidPal", "userLogin": "" });
});
//# sourceMappingURL=app.js.map