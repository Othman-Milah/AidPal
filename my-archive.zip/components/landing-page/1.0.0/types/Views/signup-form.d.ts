import { h } from "preact";
import "ojs/ojformlayout";
import "ojs/ojradioset";
import "ojs/ojoption";
import "ojs/ojcheckboxset";
import "ojs/ojcollapsible";
import "ojs/ojinputnumber";
declare type Props = Readonly<{
    userType: string;
}>;
declare const SignUpForm: ({ userType }: Props) => h.JSX.Element;
export default SignUpForm;
