export = {
 "root": {
  "landing-page": {
    "sampleString": "The strings file can be used to manage translatable resources"
  }
 },
};