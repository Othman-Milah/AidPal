declare const _default: {
    root: {
        "landing-page": {
            sampleString: string;
        };
    };
};
export = _default;
