// injector:preactDebugImport
// To learn more about preact devtools see https://preactjs.github.io/preact-devtools/
import 'preact/debug';
// endinjector
import './components/app';