import { h } from "preact";
import "ojs/ojtoolbar";
import "ojs/ojmenu";
import "ojs/ojbutton";
declare type Props = Readonly<{
    appName: string;
    userLogin: string;
    pageEventHandler: (value: string) => void;
    updateLoggedInUser: (value: string) => void;
}>;
export declare function Header({ appName, userLogin, pageEventHandler, updateLoggedInUser, }: Props): h.JSX.Element;
export {};
