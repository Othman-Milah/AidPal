var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
define(["require", "exports", "preact/jsx-runtime", "preact/hooks", "ojs/ojformlayout", "ojs/ojinputtext", "ojs/ojbutton"], function (require, exports, jsx_runtime_1, hooks_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    const SignIn = ({ pageEventHandler, updateLoggedInUser, fetchUserIfExists, }) => {
        const [username, setUsername] = (0, hooks_1.useState)("");
        const [password, setPassword] = (0, hooks_1.useState)("");
        const logIn = () => __awaiter(void 0, void 0, void 0, function* () {
            if (yield fetchUserIfExists(username, password)) {
                pageEventHandler("donor-page");
                updateLoggedInUser(username);
            }
            else {
                alert("password or username are wrong");
                setPassword("");
                setUsername("");
            }
        });
        return ((0, jsx_runtime_1.jsxs)("div", Object.assign({ class: "container" }, { children: [(0, jsx_runtime_1.jsx)("h2", Object.assign({ class: "container__h1" }, { children: "Login" })), (0, jsx_runtime_1.jsx)("p", Object.assign({ class: "container__p" }, { children: "One step at a time for a better world" })), (0, jsx_runtime_1.jsxs)("oj-form-layout", Object.assign({ id: "formLayoutOptions", "max-columns": "1", direction: "column", "user-assistance-density": "compact", class: "oj-helper-margin-auto", style: "top:50%" }, { children: [(0, jsx_runtime_1.jsx)("oj-input-text", { id: "f1", "label-hint": "Email", placeholder: "Please write your email/username", value: username, "messages-custom": "[[error]]", required: true, onrawValueChanged: (e) => {
                                var _a;
                                setUsername((_a = e.detail) === null || _a === void 0 ? void 0 : _a.value);
                            } }), (0, jsx_runtime_1.jsx)("oj-input-password", { id: "f2", "label-hint": "Password", placeholder: "please write your password", value: password, required: true, onrawValueChanged: (e) => {
                                var _a;
                                setPassword((_a = e.detail) === null || _a === void 0 ? void 0 : _a.value);
                            } }), (0, jsx_runtime_1.jsx)("oj-button", Object.assign({ id: "icon_button1", display: "icons", class: "oj-sm-width-full", onClick: () => {
                                logIn();
                            } }, { children: "Login" }))] }))] })));
    };
    exports.default = SignIn;
});
//# sourceMappingURL=sign-in.js.map