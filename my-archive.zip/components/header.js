var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
define(["require", "exports", "preact/jsx-runtime", "preact/hooks", "ojs/ojresponsiveutils", "ojs/ojtoolbar", "ojs/ojmenu", "ojs/ojbutton"], function (require, exports, jsx_runtime_1, hooks_1, ResponsiveUtils) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.Header = void 0;
    function Header({ appName, userLogin, pageEventHandler, updateLoggedInUser, }) {
        const mediaQueryRef = (0, hooks_1.useRef)(window.matchMedia(ResponsiveUtils.getFrameworkQuery("sm-only")));
        const [isSmallWidth, setIsSmallWidth] = (0, hooks_1.useState)(mediaQueryRef.current.matches);
        (0, hooks_1.useEffect)(() => {
            mediaQueryRef.current.addEventListener("change", handleMediaQueryChange);
            return () => mediaQueryRef.current.removeEventListener("change", handleMediaQueryChange);
        }, [mediaQueryRef]);
        const changeEventHandler = (e) => __awaiter(this, void 0, void 0, function* () {
            yield new Promise((resolve) => setTimeout(resolve, 0));
            pageEventHandler(e.detail.selectedValue);
            if (e.detail.selectedValue === "landing-page")
                updateLoggedInUser("");
        });
        function handleMediaQueryChange(e) {
            setIsSmallWidth(e.matches);
        }
        function getDisplayType() {
            return isSmallWidth ? "icons" : "all";
        }
        function getEndIconClass() {
            return isSmallWidth
                ? "oj-icon demo-appheader-avatar"
                : "oj-component-icon oj-button-menu-dropdown-icon";
        }
        const signIn = (e) => __awaiter(this, void 0, void 0, function* () {
            yield new Promise((resolve) => setTimeout(resolve, 0));
            pageEventHandler("sign-in");
        });
        return ((0, jsx_runtime_1.jsx)("header", Object.assign({ role: "banner", class: "oj-web-applayout-header" }, { children: (0, jsx_runtime_1.jsxs)("div", Object.assign({ class: "oj-web-applayout-max-width oj-flex-bar oj-sm-align-items-center" }, { children: [(0, jsx_runtime_1.jsx)("div", Object.assign({ class: "oj-flex-bar-middle oj-sm-align-items-baseline" }, { children: (0, jsx_runtime_1.jsx)("img", { class: "oj-icon demo-oracle-icon", src: "https://objectstorage.eu-madrid-1.oraclecloud.com/p/phYgT7WLpPuNoLhWa6dsFsoSfPXbEP2SMaCCsSLJgZnlcolVYkBzXsz7r_Pqz4oR/n/ax3ymupp8kgr/b/GCN_Bucket/o/AidPalLogoAidPal_Logo_NoBackground.png", alt: "AidPal Logo" }) })), (0, jsx_runtime_1.jsx)("div", Object.assign({ class: "oj-flex-bar-end" }, { children: userLogin === "" ? ((0, jsx_runtime_1.jsx)("a", Object.assign({ class: "landing__page__signin", value: "sign-in", onClick: signIn }, { children: "Sign In" }))) : ((0, jsx_runtime_1.jsx)("oj-toolbar", { children: (0, jsx_runtime_1.jsxs)("oj-menu-button", Object.assign({ id: "userMenu", display: getDisplayType(), chroming: "borderless" }, { children: [(0, jsx_runtime_1.jsx)("span", { children: userLogin }), (0, jsx_runtime_1.jsx)("span", { slot: "endIcon", class: getEndIconClass() }), (0, jsx_runtime_1.jsxs)("oj-menu", Object.assign({ id: "menu1", slot: "menu", onojAction: changeEventHandler }, { children: [(0, jsx_runtime_1.jsx)("oj-option", Object.assign({ id: "pref", value: "landing-page" }, { children: "Landing Page" })), (0, jsx_runtime_1.jsx)("oj-option", Object.assign({ id: "help", value: "sign-in" }, { children: "SignIn" })), (0, jsx_runtime_1.jsx)("oj-option", Object.assign({ id: "signout", value: "landing-page" }, { children: "SignOut" }))] }))] })) })) }))] })) })));
    }
    exports.Header = Header;
});
//# sourceMappingURL=header.js.map