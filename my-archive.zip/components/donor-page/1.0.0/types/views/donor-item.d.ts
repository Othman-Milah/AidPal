import { h } from "preact";
import "ojs/ojformlayout";
import "ojs/ojradioset";
import "ojs/ojoption";
import "ojs/ojselectcombobox";
import "ojs/ojinputnumber";
declare const DonorItem: () => h.JSX.Element;
export default DonorItem;
