// Do not change this file.
export { LandingPage } from "./landing-page";
declare global {
namespace preact.JSX {
      interface IntrinsicElements {
      'landing-page': any;
      }
    }
  }