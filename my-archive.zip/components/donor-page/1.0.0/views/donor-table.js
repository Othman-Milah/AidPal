define(["require", "exports", "preact/jsx-runtime", "ojs/ojmutablearraydataprovider", "ojs/ojtable"], function (require, exports, jsx_runtime_1, MutableArrayDataProvider) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    const Data = [
        {
            DonorId: 10,
            DonorName: "Othman",
            DonorEmail: "othman@gmail.com",
            DonorPhone: 987654321,
            Address: "California 11 lovik street",
            DonorAge: 10,
        },
        {
            DonorId: 10,
            DonorName: "Othman",
            DonorEmail: "othman@gmail.com",
            DonorPhone: 87654321,
            Address: "California 11 lovik street",
            DonorAge: 10,
        },
        {
            DonorId: 10,
            DonorName: "Othman",
            DonorEmail: "othman@gmail.com",
            DonorPhone: 987654321,
            Address: "California 11 lovik street",
            DonorAge: 10,
        },
        {
            DonorId: 10,
            DonorName: "Othman",
            DonorEmail: "othman@gmail.com",
            DonorPhone: 987654321,
            Address: "California 11 lovik street",
            DonorAge: 10,
        },
        {
            DonorId: 10,
            DonorName: "Othman",
            DonorEmail: "othman@gmail.com",
            DonorPhone: 987654321,
            Address: "California 11 lovik street",
            DonorAge: 10,
        },
        {
            DonorId: 10,
            DonorName: "Othman",
            DonorEmail: "othman@gmail.com",
            DonorPhone: 987654321,
            Address: "California 11 lovik street",
            DonorAge: 10,
        },
        {
            DonorId: 10,
            DonorName: "Othman",
            DonorEmail: "othman@gmail.com",
            DonorPhone: 987654321,
            Address: "California 11 lovik street",
            DonorAge: 10,
        },
        {
            DonorId: 10,
            DonorName: "Othman",
            DonorEmail: "othman@gmail.com",
            DonorPhone: 987654321,
            Address: "California 11 lovik street",
            DonorAge: 10,
        },
    ];
    const dataprovider = new MutableArrayDataProvider(Data, {
        keyAttributes: "DepartmentId",
        implicitSort: [{ attribute: "DepartmentId", direction: "ascending" }],
    });
    const DonorTable = () => {
        return ((0, jsx_runtime_1.jsx)("oj-table", { id: "table", "aria-label": "Departments Table", data: dataprovider, "selection-mode": '{"row": "multiple", "column": "multiple"}', "scroll-policy": "loadMoreOnScroll", "scroll-policy-options": '{"fetchSize": 6}', columns: [
                {
                    headerText: "DonorId",
                    field: "DonorId",
                    headerClassName: "oj-sm-only-hide",
                    className: "oj-sm-only-hide",
                    resizable: "enabled",
                    id: "DonorId",
                },
                {
                    headerText: "Name",
                    field: "DonorName",
                    resizable: "enabled",
                    id: "DonorName",
                },
                {
                    headerText: "Email",
                    field: "DonorEmail",
                    headerClassName: "oj-sm-only-hide",
                    className: "oj-sm-only-hide",
                    resizable: "enabled",
                    id: "DonorEmail",
                },
                {
                    headerText: "Phone",
                    field: "DonorPhone",
                    resizable: "enabled",
                    id: "DonorPhone",
                },
                {
                    headerText: "Address",
                    field: "DonorAddress",
                    headerClassName: "oj-md-down-hide",
                    className: "oj-md-down-hide",
                    resizable: "enabled",
                    id: "Address",
                },
                {
                    headerText: "Age",
                    field: "DonorAge",
                    headerClassName: "oj-md-down-hide",
                    className: "oj-md-down-hide",
                    resizable: "enabled",
                    id: "DonorAge",
                },
            ], class: "demo-table-container" }));
    };
    exports.default = DonorTable;
});
//# sourceMappingURL=donor-table.js.map