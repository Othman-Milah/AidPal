define(["require", "exports", "preact/jsx-runtime", "preact/hooks", "ojs/ojmutablearraydataprovider", "ojs/ojtable", "ojs/ojbutton"], function (require, exports, jsx_runtime_1, hooks_1, MutableArrayDataProvider) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    const Data = [
        {
            DonorId: 10,
            DonorName: "Othman",
            DonorEmail: "othman@gmail.com",
            DonorPhone: 987654321,
            Address: "California 11 lovik street",
            DonorAge: 10,
        },
        {
            DonorId: 10,
            DonorName: "Othman",
            DonorEmail: "othman@gmail.com",
            DonorPhone: 87654321,
            Address: "California 11 lovik street",
            DonorAge: 10,
        },
        {
            DonorId: 10,
            DonorName: "Othman",
            DonorEmail: "othman@gmail.com",
            DonorPhone: 987654321,
            Address: "California 11 lovik street",
            DonorAge: 10,
        },
        {
            DonorId: 10,
            DonorName: "Othman",
            DonorEmail: "othman@gmail.com",
            DonorPhone: 987654321,
            Address: "California 11 lovik street",
            DonorAge: 10,
        },
        {
            DonorId: 10,
            DonorName: "Othman",
            DonorEmail: "othman@gmail.com",
            DonorPhone: 987654321,
            Address: "California 11 lovik street",
            DonorAge: 10,
        },
        {
            DonorId: 10,
            DonorName: "Othman",
            DonorEmail: "othman@gmail.com",
            DonorPhone: 987654321,
            Address: "California 11 lovik street",
            DonorAge: 10,
        },
        {
            DonorId: 10,
            DonorName: "Othman",
            DonorEmail: "othman@gmail.com",
            DonorPhone: 987654321,
            Address: "California 11 lovik street",
            DonorAge: 10,
        },
        {
            DonorId: 10,
            DonorName: "Othman",
            DonorEmail: "othman@gmail.com",
            DonorPhone: 987654321,
            Address: "California 11 lovik street",
            DonorAge: 10,
        },
    ];
    const dataprovider = new MutableArrayDataProvider(Data, {
        keyAttributes: "DepartmentId",
        implicitSort: [{ attribute: "DepartmentId", direction: "ascending" }],
    });
    const DonorTable = () => {
        const [editRow, setEditRow] = (0, hooks_1.useState)();
        const cancelEdit = (0, hooks_1.useRef)(false);
        const insertNewDonation = () => {
            alert("Start");
            const url = "http://localhost:8080/donations";
            const data = {
                beneficiary: "John Doe",
                donationDate: "2023-05-11",
                deliveryId: 123,
                donorId: 1,
            };
            fetch(url, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify(data),
            })
                .then((response) => response.json())
                .then((responseData) => {
                console.log(responseData);
            })
                .catch((error) => {
                console.error("Error:", error);
            });
            alert("ENDED");
        };
        const actionColumn = () => {
            return ((0, jsx_runtime_1.jsx)("oj-button", Object.assign({ onojAction: () => {
                    insertNewDonation();
                } }, { children: "Insert" })));
        };
        return ((0, jsx_runtime_1.jsx)("oj-table", Object.assign({ id: "table", "aria-label": "Departments Table", data: dataprovider, "selection-mode": '{"row": "multiple", "column": "multiple"}', "scroll-policy": "loadMoreOnScroll", "scroll-policy-options": '{"fetchSize": 6}', columns: [
                {
                    headerText: "DonorId",
                    field: "DonorId",
                    headerClassName: "oj-sm-only-hide",
                    className: "oj-sm-only-hide",
                    resizable: "enabled",
                    id: "DonorId",
                },
                {
                    headerText: "Name",
                    field: "DonorName",
                    resizable: "enabled",
                    id: "DonorName",
                },
                {
                    headerText: "Email",
                    field: "DonorEmail",
                    headerClassName: "oj-sm-only-hide",
                    className: "oj-sm-only-hide",
                    resizable: "enabled",
                    id: "DonorEmail",
                },
                {
                    headerText: "Phone",
                    field: "DonorPhone",
                    resizable: "enabled",
                    id: "DonorPhone",
                },
                {
                    headerText: "Address",
                    field: "DonorAddress",
                    headerClassName: "oj-md-down-hide",
                    className: "oj-md-down-hide",
                    resizable: "enabled",
                    id: "Address",
                },
                {
                    headerText: "Age",
                    field: "DonorAge",
                    headerClassName: "oj-md-down-hide",
                    className: "oj-md-down-hide",
                    resizable: "enabled",
                    id: "DonorAge",
                },
                {
                    headerText: "Action",
                    resizable: "disabled",
                    template: "actionTemplate",
                },
            ], class: "demo-table-container" }, { children: (0, jsx_runtime_1.jsx)("template", { slot: "actionTemplate", render: actionColumn }) })));
    };
    exports.default = DonorTable;
});
//# sourceMappingURL=donor-table.js.map