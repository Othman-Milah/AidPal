define(["require", "exports", "preact/jsx-runtime", "ojs/ojvcomponent", "./views/donor-table", "./views/donor-package", "./views/donor-item", "css!./donor-page-styles.css"], function (require, exports, jsx_runtime_1, ojvcomponent_1, donor_table_1, donor_package_1, donor_item_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.DonorPage = void 0;
    function DonorPageImpl({ message = "Hello from  donor-page" }) {
        return ((0, jsx_runtime_1.jsxs)("div", Object.assign({ class: "donor__container" }, { children: [(0, jsx_runtime_1.jsx)("div", Object.assign({ class: "donor__donation__list" }, { children: (0, jsx_runtime_1.jsx)(donor_table_1.default, {}) })), (0, jsx_runtime_1.jsxs)("div", Object.assign({ class: "donor__donation__info" }, { children: [(0, jsx_runtime_1.jsx)("div", Object.assign({ class: "donor__donation__info__packages" }, { children: (0, jsx_runtime_1.jsx)(donor_package_1.default, {}) })), (0, jsx_runtime_1.jsx)("div", Object.assign({ class: "donor__donation__info__items" }, { children: (0, jsx_runtime_1.jsx)(donor_item_1.default, {}) }))] }))] })));
    }
    exports.DonorPage = (0, ojvcomponent_1.registerCustomElement)("donor-page", DonorPageImpl, "DonorPage", { "properties": { "message": { "type": "string" } } }, { "message": "Hello from  donor-page" });
});
//# sourceMappingURL=donor-page.js.map