import { h } from "preact";
import "ojs/ojtable";
import "ojs/ojbutton";
declare const DonorTable: () => h.JSX.Element;
export default DonorTable;
