import { h } from "preact";
import "ojs/ojinputtext";
import "ojs/ojbutton";
declare const HeroBanner: () => h.JSX.Element;
export default HeroBanner;
