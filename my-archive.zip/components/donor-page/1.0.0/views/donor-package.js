define(["require", "exports", "preact/jsx-runtime", "preact/hooks", "ojs/ojbutton", "ojs/ojconveyorbelt"], function (require, exports, jsx_runtime_1, hooks_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    const DonorPackage = () => {
        const [windowWidth, setWindowWidth] = (0, hooks_1.useState)(window.innerWidth);
        (0, hooks_1.useEffect)(() => {
            const handleResize = () => {
                setWindowWidth(window.innerWidth);
            };
            window.addEventListener("resize", handleResize);
            return () => {
                window.removeEventListener("resize", handleResize);
            };
        }, []);
        const [chemicals, setChemicals] = (0, hooks_1.useState)([
            { name: "Hydrogen" },
            { name: "Helium" },
            { name: "Lithium" },
            { name: "Beryllium" },
            { name: "Boron" },
            { name: "Carbon" },
            { name: "Nitrogen" },
            { name: "Oxygen" },
            { name: "Fluorine" },
            { name: "Neon" },
            { name: "Sodium" },
            { name: "Magnesium" },
        ]);
        return ((0, jsx_runtime_1.jsx)("div", { children: (0, jsx_runtime_1.jsx)("div", Object.assign({ id: "sampleDemo", class: "demo-padding demo-container" }, { children: (0, jsx_runtime_1.jsx)("div", Object.assign({ id: "componentDemoContent", style: "width: 1px; min-width: 100%;" }, { children: (0, jsx_runtime_1.jsx)("div", Object.assign({ id: "conveyorbelt-vertical-example" }, { children: (0, jsx_runtime_1.jsxs)("oj-conveyor-belt", Object.assign({ class: "demo-vertical-height", orientation: windowWidth > 768 ? "vertical" : "horizontal", "data-oj-binding-provider": "none" }, { children: [(0, jsx_runtime_1.jsxs)("oj-button", Object.assign({ class: "demo-ver-button oj-sm-margin-1x demo-full-height" }, { children: [(0, jsx_runtime_1.jsx)("span", { class: "oj-ux-ico-plus-circle", style: { fontSize: "xxx-large" } }), " "] })), chemicals.map((element) => ((0, jsx_runtime_1.jsx)("oj-button", Object.assign({ class: "demo-ver-button oj-sm-margin-1x demo-full-height" }, { children: element.name })))), (0, jsx_runtime_1.jsx)("oj-button", Object.assign({ class: "demo-ver-button oj-sm-margin-1x demo-full-height" }, { children: (0, jsx_runtime_1.jsx)("span", { class: "oj-ux-ico-plus-circle", style: { fontSize: "xxx-large" } }) }))] })) })) })) })) }));
    };
    exports.default = DonorPackage;
});
//# sourceMappingURL=donor-package.js.map