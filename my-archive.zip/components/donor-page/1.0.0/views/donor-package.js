define(["require", "exports", "preact/jsx-runtime", "preact/hooks", "ojs/ojbutton", "ojs/ojconveyorbelt"], function (require, exports, jsx_runtime_1, hooks_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    const DonorPackage = () => {
        const [chemicals, setChemicals] = (0, hooks_1.useState)([
            { name: "Hydrogen" },
            { name: "Helium" },
            { name: "Lithium" },
            { name: "Beryllium" },
            { name: "Boron" },
            { name: "Carbon" },
            { name: "Nitrogen" },
            { name: "Oxygen" },
            { name: "Fluorine" },
            { name: "Neon" },
            { name: "Sodium" },
            { name: "Magnesium" },
        ]);
        return ((0, jsx_runtime_1.jsx)("div", { children: (0, jsx_runtime_1.jsx)("div", Object.assign({ id: "sampleDemo", class: "demo-padding demo-container" }, { children: (0, jsx_runtime_1.jsx)("div", Object.assign({ id: "componentDemoContent", style: "width: 1px; min-width: 100%;" }, { children: (0, jsx_runtime_1.jsx)("div", Object.assign({ id: "conveyorbelt-vertical-example" }, { children: (0, jsx_runtime_1.jsx)("oj-conveyor-belt", Object.assign({ class: "demo-vertical-height", orientation: "vertical", "data-oj-binding-provider": "none" }, { children: chemicals.map((element) => ((0, jsx_runtime_1.jsx)("oj-button", Object.assign({ class: "demo-ver-button oj-sm-margin-1x" }, { children: element.name })))) })) })) })) })) }));
    };
    exports.default = DonorPackage;
});
//# sourceMappingURL=donor-package.js.map