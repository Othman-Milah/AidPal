define(["require", "exports", "./landing-page"], function (require, exports, landing_page_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.LandingPage = void 0;
    Object.defineProperty(exports, "LandingPage", { enumerable: true, get: function () { return landing_page_1.LandingPage; } });
});
//# sourceMappingURL=loader.js.map