define(["require", "exports", "./donor-page"], function (require, exports, donor_page_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.DonorPage = void 0;
    Object.defineProperty(exports, "DonorPage", { enumerable: true, get: function () { return donor_page_1.DonorPage; } });
});
//# sourceMappingURL=loader.js.map