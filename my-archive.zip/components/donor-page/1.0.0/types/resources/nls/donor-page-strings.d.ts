declare const _default: {
    root: {
        "donor-page": {
            sampleString: string;
        };
    };
};
export = _default;
