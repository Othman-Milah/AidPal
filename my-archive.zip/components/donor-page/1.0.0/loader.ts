// Do not change this file.
export { DonorPage } from "./donor-page";
declare global {
namespace preact.JSX {
      interface IntrinsicElements {
      'donor-page': any;
      }
    }
  }