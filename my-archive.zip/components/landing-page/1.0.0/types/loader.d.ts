export { LandingPage } from "./landing-page";
declare global {
    namespace preact.JSX {
        interface IntrinsicElements {
            'landing-page': any;
        }
    }
}
export { PageElement } from './landing-page';