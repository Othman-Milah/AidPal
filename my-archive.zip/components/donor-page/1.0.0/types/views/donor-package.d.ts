import { h } from "preact";
import "ojs/ojbutton";
import "ojs/ojconveyorbelt";
declare const DonorPackage: () => h.JSX.Element;
export default DonorPackage;
