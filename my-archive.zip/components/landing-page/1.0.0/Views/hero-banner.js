define(["require", "exports", "preact/jsx-runtime", "preact/hooks", "ojs/ojinputtext", "ojs/ojbutton"], function (require, exports, jsx_runtime_1, hooks_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    const HeroBanner = () => {
        const [email, setEmail] = (0, hooks_1.useState)("");
        const updateEmail = (e) => {
            var _a;
            setEmail((_a = e.detail) === null || _a === void 0 ? void 0 : _a.value);
        };
        const sendEmailTo = (e) => {
            e.preventDefault();
            fetch("http://localhost:8080/email/basic", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify({}),
            })
                .then((response) => {
                alert("email sent");
            })
                .catch((error) => {
                console.error(error);
            });
        };
        return ((0, jsx_runtime_1.jsxs)("section", Object.assign({ class: "hero__banner" }, { children: [(0, jsx_runtime_1.jsxs)("div", Object.assign({ class: "hero__content" }, { children: [(0, jsx_runtime_1.jsx)("h1", { children: "Welcome To AidPal" }), (0, jsx_runtime_1.jsx)("p", { children: "Our mission is to create a platform that enables donors and beneficiaries to connect with ease, so that no one in our community goes without basic needs such as food and clothing. By leveraging the power of technology and community, we aim to streamline the donation process and provide a more efficient and effective solution for those in need." }), (0, jsx_runtime_1.jsxs)("form", Object.assign({ class: "hero__content__form" }, { children: [(0, jsx_runtime_1.jsx)("oj-input-text", { id: "text-email-input", value: email, "label-hint": "Email", "label-edge": "inside", onrawValueChanged: (e) => {
                                        updateEmail(e);
                                    } }), (0, jsx_runtime_1.jsxs)("oj-button", Object.assign({ id: "emailbutton", onojAction: sendEmailTo }, { children: [(0, jsx_runtime_1.jsx)("span", { slot: "endIcon", class: "oj-ux-ico-email" }), "Send"] }))] }))] })), (0, jsx_runtime_1.jsx)("img", { class: "hero__content__image", src: "https://objectstorage.eu-madrid-1.oraclecloud.com/p/OJIuG4yQ3weQQ3QRoaJ3XSp46vK3grc18Hsj8Nqc6kYZf3WJeHxSjxEkEjFqtUzp/n/ax3ymupp8kgr/b/GCN_Bucket/o/Piggybiggy.jpg", alt: "Hero Image" })] })));
    };
    exports.default = HeroBanner;
});
//# sourceMappingURL=hero-banner.js.map