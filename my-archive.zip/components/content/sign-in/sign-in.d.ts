import { h } from "preact";
import "ojs/ojformlayout";
import "ojs/ojinputtext";
import "ojs/ojbutton";
declare type Props = {
    pageEventHandler: (value: string) => void;
    updateLoggedInUser: (value: string) => void;
    fetchUserIfExists: (username: string, password: string) => Promise<boolean>;
};
declare const SignIn: ({ pageEventHandler, updateLoggedInUser, fetchUserIfExists, }: Props) => h.JSX.Element;
export default SignIn;
