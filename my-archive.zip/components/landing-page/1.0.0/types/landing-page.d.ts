import { JetElement, JetSettableProperties, JetElementCustomEventStrict, JetSetPropertyType } from 'ojs/index';
import { GlobalProps } from 'ojs/ojvcomponent';
import 'ojs/oj-jsx-interfaces';
import { ExtendGlobalProps } from "ojs/ojvcomponent";
import { h, ComponentProps, ComponentType } from "preact";
import "css!./landing-page-styles.css";
declare type Props = Readonly<{
    message?: string;
}>;
declare function LandingPageImpl({ message }: Props): h.JSX.Element;
export declare const LandingPage: ComponentType<ExtendGlobalProps<ComponentProps<typeof LandingPageImpl>>>;
export {};
export interface PageElement extends JetElement<PageElementSettableProperties>, PageElementSettableProperties {
    addEventListener<T extends keyof PageElementEventMap>(type: T, listener: (this: HTMLElement, ev: PageElementEventMap[T]) => any, options?: (boolean | AddEventListenerOptions)): void;
    addEventListener(type: string, listener: EventListenerOrEventListenerObject, options?: (boolean | AddEventListenerOptions)): void;
    getProperty<T extends keyof PageElementSettableProperties>(property: T): PageElement[T];
    getProperty(property: string): any;
    setProperty<T extends keyof PageElementSettableProperties>(property: T, value: PageElementSettableProperties[T]): void;
    setProperty<T extends string>(property: T, value: JetSetPropertyType<T, PageElementSettableProperties>): void;
    setProperties(properties: PageElementSettablePropertiesLenient): void;
}
export namespace PageElement {
    type messageChanged = JetElementCustomEventStrict<PageElement['message']>;
}
export interface PageElementEventMap extends HTMLElementEventMap {
    'messageChanged': JetElementCustomEventStrict<PageElement['message']>;
}
export interface PageElementSettableProperties extends JetSettableProperties {
    message?: Props['message'];
}
export interface PageElementSettablePropertiesLenient extends Partial<PageElementSettableProperties> {
    [key: string]: any;
}
export interface LandingPageIntrinsicProps extends Partial<Readonly<PageElementSettableProperties>>, GlobalProps, Pick<preact.JSX.HTMLAttributes, 'ref' | 'key'> {
    onmessageChanged?: (value: PageElementEventMap['messageChanged']) => void;
}
declare global {
    namespace preact.JSX {
        interface IntrinsicElements {
            'landing-page': LandingPageIntrinsicProps;
        }
    }
}
