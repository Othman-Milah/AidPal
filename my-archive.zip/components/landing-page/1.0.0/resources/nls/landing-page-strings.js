define(["require", "exports"], function (require, exports) {
    "use strict";
    return {
        "root": {
            "landing-page": {
                "sampleString": "The strings file can be used to manage translatable resources"
            }
        },
    };
});
//# sourceMappingURL=landing-page-strings.js.map