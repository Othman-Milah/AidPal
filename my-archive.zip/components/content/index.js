define(["require", "exports", "preact/jsx-runtime", "landing-page/landing-page", "./sign-in/sign-in", "donor-page/donor-page"], function (require, exports, jsx_runtime_1, landing_page_1, sign_in_1, donor_page_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.Content = void 0;
    function Content({ page, pageEventHandler, updateLoggedInUser, fetchUserIfExists, }) {
        let pageContent = (page) => {
            switch (page) {
                case "landing-page":
                    return (0, jsx_runtime_1.jsx)(landing_page_1.LandingPage, {});
                case "sign-in":
                    return ((0, jsx_runtime_1.jsx)(sign_in_1.default, { pageEventHandler: pageEventHandler, updateLoggedInUser: updateLoggedInUser, fetchUserIfExists: fetchUserIfExists }));
                case "donor-page":
                    return (0, jsx_runtime_1.jsx)(donor_page_1.DonorPage, {});
            }
        };
        return ((0, jsx_runtime_1.jsx)("div", Object.assign({ class: "oj-web-applayout-max-width oj-web-applayout-content" }, { children: pageContent(page) })));
    }
    exports.Content = Content;
});
//# sourceMappingURL=index.js.map