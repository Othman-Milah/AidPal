define(["require", "exports", "preact/jsx-runtime", "preact/hooks", "ojs/ojformlayout", "ojs/ojradioset", "ojs/ojoption", "ojs/ojcheckboxset", "ojs/ojcollapsible", "ojs/ojinputnumber"], function (require, exports, jsx_runtime_1, hooks_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    const SignUpForm = ({ userType }) => {
        const [email, setEmail] = (0, hooks_1.useState)("");
        const [name, setName] = (0, hooks_1.useState)("");
        const [lastName, setLastName] = (0, hooks_1.useState)("");
        const [phoneNumber, setPhoneNumber] = (0, hooks_1.useState)("");
        const [address, setAddresse] = (0, hooks_1.useState)("");
        const [age, setAge] = (0, hooks_1.useState)(0);
        const [username, setUsername] = (0, hooks_1.useState)("");
        const [password, setPassword] = (0, hooks_1.useState)("");
        const closePanel = () => {
            var _a;
            (_a = document.querySelector("#slide-out-container")) === null || _a === void 0 ? void 0 : _a.classList.toggle("show");
        };
        const submit = (e) => {
            alert("Hey");
            e.preventDefault();
            const form = e.target;
            const data = {
                name: name,
                email: email,
                phone: phoneNumber,
                address: address,
                age: age,
                username: username,
            };
            fetch("http://localhost:8080/donors", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify(data),
            })
                .then((response) => {
                if (!response.ok) {
                    throw new Error("Network response was not ok");
                }
                return response.json();
            })
                .then((data) => {
                console.log("Success:", data);
            })
                .catch((error) => {
                console.error("Error:", error);
            });
        };
        return ((0, jsx_runtime_1.jsxs)("oj-form-layout", Object.assign({ id: "formLayoutOptions", "max-columns": "2", direction: "row", "user-assistance-density": "compact" }, { children: [(0, jsx_runtime_1.jsx)("oj-input-text", { id: "input-email-id", labelHint: "Email", placeholder: "Please provide a valid email address", value: email, onrawValueChanged: (e) => {
                        var _a;
                        setEmail((_a = e.detail) === null || _a === void 0 ? void 0 : _a.value);
                    }, required: true }), (0, jsx_runtime_1.jsx)("oj-input-text", { id: "input-name-id", labelHint: "Name", placeholder: "Please provide your legal name", value: name, onrawValueChanged: (e) => {
                        var _a;
                        setName((_a = e.detail) === null || _a === void 0 ? void 0 : _a.value);
                        setUsername(name + lastName + age);
                    }, required: true }), (0, jsx_runtime_1.jsx)("oj-input-text", { id: "input-lastname-id", labelHint: "Last Name", placeholder: "Please provide your legal last name", value: lastName, onrawValueChanged: (e) => {
                        var _a;
                        setLastName((_a = e.detail) === null || _a === void 0 ? void 0 : _a.value);
                        setUsername(name + lastName + age);
                    }, required: true }), (0, jsx_runtime_1.jsx)("oj-input-text", { id: "input-phonenumber-id", labelHint: "Phone Number", placeholder: "Please provide your phone number", value: phoneNumber, onrawValueChanged: (e) => {
                        var _a;
                        setPhoneNumber((_a = e.detail) === null || _a === void 0 ? void 0 : _a.value);
                    }, required: true }), (0, jsx_runtime_1.jsx)("oj-input-number", { id: "input-age-id", "label-hint": "Please provide your age", max: 120, min: 0, step: 1, placeholder: "Please provide your age", value: age, required: true, onrawValueChanged: (e) => {
                        var _a;
                        setAge((_a = e.detail) === null || _a === void 0 ? void 0 : _a.value);
                        setUsername(name + lastName + age);
                    } }), (0, jsx_runtime_1.jsx)("oj-text-area", { id: "input-address-id", "label-hint": "Please provide your current living address", "max-rows": "-1", placeholder: "Provide your current adresse", value: address, onrawValueChanged: (e) => {
                        var _a;
                        setAddresse((_a = e.detail) === null || _a === void 0 ? void 0 : _a.value);
                    }, required: true }), (0, jsx_runtime_1.jsx)("oj-input-text", { id: "input-username-id", labelHint: "Username", placeholder: "Your username will be your full name + your age", value: username, disabled: true }), (0, jsx_runtime_1.jsx)("oj-input-password", { id: "f2", "label-hint": "Password", placeholder: "please write your password", value: password, "messages-custom": "{{messages}}", required: true, onrawValueChanged: (e) => {
                        var _a;
                        setPassword((_a = e.detail) === null || _a === void 0 ? void 0 : _a.value);
                    } }), (0, jsx_runtime_1.jsxs)("oj-collapsible", Object.assign({ class: "oj-sm-margin-4x-bottom" }, { children: [(0, jsx_runtime_1.jsx)("h6", Object.assign({ slot: "header" }, { children: "Advanced options" })), (0, jsx_runtime_1.jsxs)("div", Object.assign({ class: "oj-panel oj-bg-info-30" }, { children: [userType === "Volunteer" && ((0, jsx_runtime_1.jsxs)("oj-radioset", Object.assign({ "label-hint": "Availability", value: "{{Availability}}", "aria-controls": "myform" }, { children: [(0, jsx_runtime_1.jsx)("oj-option", Object.assign({ value: "top" }, { children: "Available" })), (0, jsx_runtime_1.jsx)("oj-option", Object.assign({ value: "inside" }, { children: "not Available" }))] }))), userType === "Beneficiary" && ((0, jsx_runtime_1.jsxs)("oj-checkboxset", Object.assign({ "label-hint": "Disabilities", id: "stylesBooleans" }, { children: [(0, jsx_runtime_1.jsxs)("oj-option", Object.assign({ value: "Mobility impairments" }, { children: ["Mobility impairments", " "] })), (0, jsx_runtime_1.jsx)("oj-option", Object.assign({ value: "Visual impairments" }, { children: "Visual impairments" })), (0, jsx_runtime_1.jsx)("oj-option", Object.assign({ value: "Hearing impairments" }, { children: "Hearing impairments" })), (0, jsx_runtime_1.jsx)("oj-option", Object.assign({ value: "Mental health impairments" }, { children: "Mental health impairments" })), (0, jsx_runtime_1.jsx)("oj-option", Object.assign({ value: "Chronic illnesses" }, { children: "Chronic illnesses" }))] })))] }))] })), (0, jsx_runtime_1.jsx)("br", {}), (0, jsx_runtime_1.jsxs)("div", Object.assign({ class: "form__layout__buttons" }, { children: [(0, jsx_runtime_1.jsx)("oj-button", Object.assign({ onojAction: submit }, { children: "Submit" })), (0, jsx_runtime_1.jsx)("oj-button", Object.assign({ onojAction: closePanel }, { children: "Close" }))] }))] })));
    };
    exports.default = SignUpForm;
});
//# sourceMappingURL=signup-form.js.map