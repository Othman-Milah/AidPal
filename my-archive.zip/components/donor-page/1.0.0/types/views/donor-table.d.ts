import { h } from "preact";
import "ojs/ojtable";
declare const DonorTable: () => h.JSX.Element;
export default DonorTable;
