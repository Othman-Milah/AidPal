define(["require", "exports", "preact/jsx-runtime", "ojs/ojvcomponent", "./Views/hero-banner", "./Views/signup-section", "./Views/signup-form", "preact/hooks", "css!./landing-page-styles.css"], function (require, exports, jsx_runtime_1, ojvcomponent_1, hero_banner_1, signup_section_1, signup_form_1, hooks_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.LandingPage = void 0;
    const userTypesInfo = [
        {
            title: "Beneficiary",
            description: "a person who receives donations of food or clothing from our donors. By signing up as a beneficiary, you can gain access to these donations to help support yourself or your organization.",
            icon: "oj-ux-ico-blood-donation",
            image: "https://objectstorage.eu-madrid-1.oraclecloud.com/p/VahhCM3h6hfK5bsrsr1Y_oURuYzd460m0XoNZk7aspsquE0HnGN3FBClM4Jqoez_/n/ax3ymupp8kgr/b/GCN_Bucket/o/BenDonVolpattern-gb08752b1e_1920.jpg",
        },
        {
            title: "Donor",
            description: "a donor is someone who donates food or clothing to benefit others . By signing up as a donor, you can make a difference in your community by providing support to those who need it most.",
            icon: "oj-ux-ico-loan-request",
            image: "https://objectstorage.eu-madrid-1.oraclecloud.com/p/VahhCM3h6hfK5bsrsr1Y_oURuYzd460m0XoNZk7aspsquE0HnGN3FBClM4Jqoez_/n/ax3ymupp8kgr/b/GCN_Bucket/o/BenDonVolpattern-gb08752b1e_1920.jpg",
        },
        {
            title: "Volunteer",
            description: "a volunteer is someone who helps with tasks such as collecting and distributing donations. By signing up as a volunteer, you can play an active role in supporting your community and making a positive impact on the lives of others.",
            icon: "oj-ux-ico-bandaid",
            image: "https://objectstorage.eu-madrid-1.oraclecloud.com/p/VahhCM3h6hfK5bsrsr1Y_oURuYzd460m0XoNZk7aspsquE0HnGN3FBClM4Jqoez_/n/ax3ymupp8kgr/b/GCN_Bucket/o/BenDonVolpattern-gb08752b1e_1920.jpg",
        },
    ];
    function LandingPageImpl({ message = "Hello from  landing-page" }) {
        const [userType, setUserType] = (0, hooks_1.useState)("");
        const setUserTypeFunc = (userType) => {
            setUserType(userType);
        };
        return ((0, jsx_runtime_1.jsxs)("div", { children: [(0, jsx_runtime_1.jsxs)("div", Object.assign({ style: "z-index:100", id: "slide-out-container" }, { children: [(0, jsx_runtime_1.jsxs)("oj-label", Object.assign({ class: "signup__label" }, { children: ["Sign Up as ", userType] })), (0, jsx_runtime_1.jsx)("hr", { style: "margin-top:2rem;margin-bottom:1rem" }), (0, jsx_runtime_1.jsx)(signup_form_1.default, { userType: userType })] })), (0, jsx_runtime_1.jsx)(hero_banner_1.default, {}), userTypesInfo.map((userType) => ((0, jsx_runtime_1.jsx)(signup_section_1.default, { title: userType.title, description: userType.description, icon: userType.icon, image: userType.image, setUserTypeFunc: setUserTypeFunc })))] }));
    }
    exports.LandingPage = (0, ojvcomponent_1.registerCustomElement)("landing-page", LandingPageImpl, "LandingPage", { "properties": { "message": { "type": "string" } } }, { "message": "Hello from  landing-page" });
});
//# sourceMappingURL=landing-page.js.map