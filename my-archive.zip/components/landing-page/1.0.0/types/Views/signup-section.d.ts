import { h } from "preact";
import "ojs/ojbutton";
import "ojs/ojlabel";
declare type Props = Readonly<{
    title: string;
    description: String;
    icon: string;
    image: string;
    setUserTypeFunc: (userType: string) => void;
}>;
declare const SignupSection: ({ title, description, icon, image, setUserTypeFunc, }: Props) => h.JSX.Element;
export default SignupSection;
