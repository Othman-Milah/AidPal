import { h } from "preact";
declare type Props = {
    page: string;
    pageEventHandler: (value: string) => void;
    updateLoggedInUser: (value: string) => void;
    fetchUserIfExists: (username: string, password: string) => Promise<boolean>;
};
export declare function Content({ page, pageEventHandler, updateLoggedInUser, fetchUserIfExists, }: Props): h.JSX.Element;
export {};
