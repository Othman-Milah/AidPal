define(["require", "exports"], function (require, exports) {
    "use strict";
    return {
        "root": {
            "donor-page": {
                "sampleString": "The strings file can be used to manage translatable resources"
            }
        },
    };
});
//# sourceMappingURL=donor-page-strings.js.map